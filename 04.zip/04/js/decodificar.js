function decodificarMensaje() {
    const mensajeCodificado = document.getElementById("mensajeCodificado").value;

    const regex = /\((.*?)\)/g;
    let mensajeDecodificado = mensajeCodificado;

    let match;
    while ((match = regex.exec(mensajeCodificado)) !== null) {
        const fragmentoCodificado = match[1];
        const fragmentoDecodificado = fragmentoCodificado.split('').reverse().join('');
        mensajeDecodificado = mensajeDecodificado.replace(`(${fragmentoCodificado})`, fragmentoDecodificado);
    }

    document.getElementById("mensajeDecodificado").textContent = mensajeDecodificado;
}
